data(diamonds)
diamonds$ppc <- diamonds$price/diamonds$carat

fair.ppc <- diamonds$ppc[diamonds$cut=="Fair"]
ideal.ppc <- diamonds$ppc[diamonds$cut=="Ideal"]

summary(fair.ppc)
summary(ideal.ppc)

t.test(fair.ppc, ideal.ppc)

library(ggplot2)
qplot(data=diamonds[which(diamonds$cut=="Fair"),], x=carat, y=price)
qplot(data=diamonds[which(diamonds$cut=="Ideal"),], x=carat, y=price)