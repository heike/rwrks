## Your turn 1
x <- 3
y <- 5
sqrt(x^2 + y^5)
sin(exp(2*pi*(x+y)/y-x))

a <- 3
b <- -2
c <- -17  # Bad practice!
(-b + sqrt(b^2 - 4*a*c))/(2*a)
(-b - sqrt(b^2 - 4*a*c))/(2*a)
polyroot(c(-17, -2, 3))
uniroot(function(x){a*x^2+b*x+c}, lower = 0, upper = 10)

## Your turn 2
x <- c(4, 1, 3, 9)
y <- c(1, 2, 3, 5)
d <- sqrt(sum( (x-y)^2 ))
2*(y[1] + x[2])
z <- 1:100
sum(z)^2 - sum(z^2)
pattern <- rep(seq(1, 31, 6), 1:6)



## Your turn 3
mean(rnorm(10))
mean(rnorm(1000))
mean(rnorm(10000))
z <- rnorm(1000000)
quantile(z^2, .95)
qchisq(.95, 1)

x <- rnorm(100, 5, 6)
mean(x) + qt(.975, 99)*sd(x)/sqrt(100)
mean(x) - qt(.975, 99)*sd(x)/sqrt(100)

confint(lm(x ~ 1))


## Your turn 4
pat <- seq(2, 103, by = 3)
x <- pat[c(F, T)]
y <- pat[pat > mean(pat)]
z <- pat[pat %% 2 == 0]

?which
pat %% 7
(pat %% 7) == 0
which((pat %% 7) == 0)
pat[which((pat %% 7) == 0)]
pat[pat %% 7 == 0]