##### Your Turn Solutions (Karsten Sections) #####

### Motivating Example ###

head(tips)

# summary of total bills
summary(tips$total_bill)

#boxplots of rate by day of week
qplot(day, rate, geom="boxplot",data=tips)

#average tip size for smokers
mean(tips$tip[tips$smoker=="Yes"])






#------------------------------------------------------



### Data Structures ###

## Data Frames
newdf <- data.frame(nums=1:6, lets=rep(letters[1:2],3))
newdf
#subset out the rows with a's
newdf[which(newdf$lets=="a"), ]  
#motor trend cars data
head(mtcars)
#4th row
mtcars[4,]
  

## Lists
mylist <- list(1:5, newdf)
mylist
#pull off the data frame
mylist[[2]]
#pulls off just the first row of the data frame
mylist[[2]][1,]
  
  
## Examining Objects
head(mtcars)
#type of object?
str(mtcars)
# number of rows in iris?
dim(iris)
# -or-
length(iris[,1])
#summarize data in iris
summary(iris)


## Saving output as an object
t.test(Sepal.Length ~ Species, data=iris[iris$Species!="virginica",])
# save the output of the t-test to an object
tout2 <- t.test(Sepal.Length ~ Species, data=iris[iris$Species!="virginica",])
# can use the str() function to examine the output type
str(tout2)
# pull off the pvalue
tout2$p.value


## Reading in text file
yourturndata <- read.table("yourturndata.txt",header=T)
yourturndata
  

