conf.interval <- function(x){
  stderr <- sqrt(var(x)/length(x))
  return(data.frame(lb=mean(x)-1.96*stderr,
                    mean=mean(x), 
                    ub=mean(x)+1.96*stderr))
}


conf.interval <- function(x){
  if(!(is.numeric(x)|is.logical(x))) return("ERROR: Data must be numeric") 
  stderr <- sqrt(var(x)/length(x))
  return(data.frame(lb=mean(x)-1.96*stderr,
                    mean=mean(x), 
                    ub=mean(x)+1.96*stderr))
}

conf.interval(rnorm(100,2,1))

library(ggplot2)
data(diamonds)

apply(diamonds[,-c(2:4)], 2, conf.interval) # remove non-numeric vars
sapply(diamonds,  conf.interval) # sapply can be nicer

for(i in 1:ncol(diamonds)) {
  print(names(diamonds)[i])
  print(conf.interval(diamonds[,i]))
}
